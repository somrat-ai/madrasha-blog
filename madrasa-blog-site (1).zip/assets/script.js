
// Mobile menu toggle
const toggle = document.querySelector('.mobile-toggle');
const mobileMenu = document.querySelector('.mobile-menu');
if (toggle && mobileMenu){
  toggle.addEventListener('click', ()=> mobileMenu.classList.toggle('open'));
}

// Simple client-side filter for lists (teachers/students/committee)
function filterCards(inputId, listClass){
  const q = document.getElementById(inputId).value.toLowerCase();
  document.querySelectorAll(`.${listClass} .card`).forEach(card=>{
    const text = card.innerText.toLowerCase();
    card.style.display = text.includes(q) ? '' : 'none';
  });
}
